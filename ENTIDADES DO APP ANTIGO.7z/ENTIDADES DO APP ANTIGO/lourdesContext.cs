﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace School.WebApi
{
    public partial class lourdesContext : DbContext
    {
        public lourdesContext()
        {
        }

        public lourdesContext(DbContextOptions<lourdesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Aluno> Aluno { get; set; }
        public virtual DbSet<AulasDadas> AulasDadas { get; set; }
        public virtual DbSet<Avaliacao> Avaliacao { get; set; }
        public virtual DbSet<CentroCusto> CentroCusto { get; set; }
        public virtual DbSet<Cidades> Cidades { get; set; }
        public virtual DbSet<ContParametrosIni> ContParametrosIni { get; set; }
        public virtual DbSet<ContaCorrente> ContaCorrente { get; set; }
        public virtual DbSet<ContatoProspect> ContatoProspect { get; set; }
        public virtual DbSet<DescricaoPgto> DescricaoPgto { get; set; }
        public virtual DbSet<DiaTurma> DiaTurma { get; set; }
        public virtual DbSet<Disponibilidade> Disponibilidade { get; set; }
        public virtual DbSet<FecMovBancario> FecMovBancario { get; set; }
        public virtual DbSet<FechamentoCaixa> FechamentoCaixa { get; set; }
        public virtual DbSet<FechamentoCaixaTmp> FechamentoCaixaTmp { get; set; }
        public virtual DbSet<FechamentoProduto> FechamentoProduto { get; set; }
        public virtual DbSet<Feriados> Feriados { get; set; }
        public virtual DbSet<FormaPgtoPar> FormaPgtoPar { get; set; }
        public virtual DbSet<Fornecedores> Fornecedores { get; set; }
        public virtual DbSet<GrupoProdutos> GrupoProdutos { get; set; }
        public virtual DbSet<Habilitado> Habilitado { get; set; }
        public virtual DbSet<HistoricoLotenfe> HistoricoLotenfe { get; set; }
        public virtual DbSet<Idiomas> Idiomas { get; set; }
        public virtual DbSet<Inventario> Inventario { get; set; }
        public virtual DbSet<ItensFecProduto> ItensFecProduto { get; set; }
        public virtual DbSet<ItensNfEntrada> ItensNfEntrada { get; set; }
        public virtual DbSet<ItensPedido> ItensPedido { get; set; }
        public virtual DbSet<LctoInventario> LctoInventario { get; set; }
        public virtual DbSet<LogAtividades> LogAtividades { get; set; }
        public virtual DbSet<LotesNfe> LotesNfe { get; set; }
        public virtual DbSet<Matricula> Matricula { get; set; }
        public virtual DbSet<MovBancario> MovBancario { get; set; }
        public virtual DbSet<NfEntrada> NfEntrada { get; set; }
        public virtual DbSet<NfSaidas> NfSaidas { get; set; }
        public virtual DbSet<Nivel> Nivel { get; set; }
        public virtual DbSet<Numeracoes> Numeracoes { get; set; }
        public virtual DbSet<Operador> Operador { get; set; }
        public virtual DbSet<ParametrosIni> ParametrosIni { get; set; }
        public virtual DbSet<ParametrosUnidade> ParametrosUnidade { get; set; }
        public virtual DbSet<Parcelas> Parcelas { get; set; }
        public virtual DbSet<Pedido> Pedido { get; set; }
        public virtual DbSet<PerfilOp> PerfilOp { get; set; }
        public virtual DbSet<PermissoesPerfil> PermissoesPerfil { get; set; }
        public virtual DbSet<PgtoMat> PgtoMat { get; set; }
        public virtual DbSet<PrecoProduto> PrecoProduto { get; set; }
        public virtual DbSet<Precos> Precos { get; set; }
        public virtual DbSet<Produto> Produto { get; set; }
        public virtual DbSet<Professor> Professor { get; set; }
        public virtual DbSet<ProfessorTurma> ProfessorTurma { get; set; }
        public virtual DbSet<ProfessoresTurma> ProfessoresTurma { get; set; }
        public virtual DbSet<Prospect> Prospect { get; set; }
        public virtual DbSet<ProvdescProf> ProvdescProf { get; set; }
        public virtual DbSet<ProventosDesc> ProventosDesc { get; set; }
        public virtual DbSet<Recibo> Recibo { get; set; }
        public virtual DbSet<RespFinanceiro> RespFinanceiro { get; set; }
        public virtual DbSet<RespMat> RespMat { get; set; }
        public virtual DbSet<Sala> Sala { get; set; }
        public virtual DbSet<SaldoProduto> SaldoProduto { get; set; }
        public virtual DbSet<TipoTarifa> TipoTarifa { get; set; }
        public virtual DbSet<Turma> Turma { get; set; }
        public virtual DbSet<Unidades> Unidades { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("server=localhost;userid=developer;password=1234567;database=lourdes", x => x.ServerVersion("8.0.21-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Aluno>(entity =>
            {
                entity.HasKey(e => new { e.IdAluno, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("aluno");

                entity.HasIndex(e => e.IdUnidade)
                    .HasName("FK_REFERENCE_19");

                entity.Property(e => e.IdAluno).HasColumnName("ID_ALUNO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Bairro)
                    .HasColumnName("BAIRRO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cep)
                    .HasColumnName("CEP")
                    .HasColumnType("char(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cidade)
                    .HasColumnName("CIDADE")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Complemento)
                    .HasColumnName("COMPLEMENTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cpf)
                    .HasColumnName("CPF")
                    .HasColumnType("char(11)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataCadastro)
                    .HasColumnName("DATA_CADASTRO")
                    .HasColumnType("datetime");

                entity.Property(e => e.EMail)
                    .HasColumnName("E_MAIL")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Endereco)
                    .HasColumnName("ENDERECO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.EstadoCivil).HasColumnName("ESTADO_CIVIL");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Nascimento)
                    .HasColumnName("NASCIMENTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Numero)
                    .HasColumnName("NUMERO")
                    .HasColumnType("char(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Sexo).HasColumnName("SEXO");

                entity.Property(e => e.TelCel)
                    .HasColumnName("TEL_CEL")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.TelCom)
                    .HasColumnName("TEL_COM")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.TelRes)
                    .HasColumnName("TEL_RES")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Uf)
                    .HasColumnName("UF")
                    .HasColumnType("char(2)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.HasOne(d => d.IdUnidadeNavigation)
                    .WithMany(p => p.Aluno)
                    .HasForeignKey(d => d.IdUnidade)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_19");
            });

            modelBuilder.Entity<AulasDadas>(entity =>
            {
                entity.HasKey(e => new { e.IdAula, e.IdTurma, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("aulas_dadas");

                entity.HasIndex(e => e.IdProfessor)
                    .HasName("FK_REFERENCE_11");

                entity.HasIndex(e => e.IdTarifa)
                    .HasName("FK_REFERENCE_12");

                entity.HasIndex(e => new { e.IdTurma, e.IdUnidade })
                    .HasName("FK_REFERENCE_20");

                entity.Property(e => e.IdAula).HasColumnName("ID_AULA");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.DataAula)
                    .HasColumnName("DATA_AULA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.HoraFim)
                    .HasColumnName("HORA_FIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.HoraIni)
                    .HasColumnName("HORA_INI")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");

                entity.Property(e => e.IdTarifa).HasColumnName("ID_TARIFA");

                entity.Property(e => e.Obs)
                    .HasColumnName("OBS")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.TotalMin).HasColumnName("TOTAL_MIN");

                entity.Property(e => e.ValorAula)
                    .HasColumnName("VALOR_AULA")
                    .HasColumnType("decimal(10,4)");

                entity.HasOne(d => d.IdProfessorNavigation)
                    .WithMany(p => p.AulasDadas)
                    .HasForeignKey(d => d.IdProfessor)
                    .HasConstraintName("FK_REFERENCE_11");

                entity.HasOne(d => d.IdTarifaNavigation)
                    .WithMany(p => p.AulasDadas)
                    .HasForeignKey(d => d.IdTarifa)
                    .HasConstraintName("FK_REFERENCE_12");

                entity.HasOne(d => d.Id)
                    .WithMany(p => p.AulasDadas)
                    .HasForeignKey(d => new { d.IdTurma, d.IdUnidade })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_20");
            });

            modelBuilder.Entity<Avaliacao>(entity =>
            {
                entity.HasKey(e => new { e.IdTurma, e.IdUnidade, e.IdMatricula, e.Bimestre })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0, 0 });

                entity.ToTable("avaliacao");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdMatricula).HasColumnName("ID_MATRICULA");

                entity.Property(e => e.Bimestre).HasColumnName("BIMESTRE");

                entity.Property(e => e.AtivExtra)
                    .HasColumnName("ATIV_EXTRA")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.AulasAssistidas).HasColumnName("AULAS_ASSISTIDAS");

                entity.Property(e => e.AulasDadas).HasColumnName("AULAS_DADAS");

                entity.Property(e => e.CompAud)
                    .HasColumnName("COMP_AUD")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.Comprometimento)
                    .HasColumnName("COMPROMETIMENTO")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.Envolv)
                    .HasColumnName("ENVOLV")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.Faltas).HasColumnName("FALTAS");

                entity.Property(e => e.HabEst)
                    .HasColumnName("HAB_EST")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.Inter)
                    .HasColumnName("INTER")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.ProvaE)
                    .HasColumnName("PROVA_E")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.ProvaO)
                    .HasColumnName("PROVA_O")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.Redacao)
                    .HasColumnName("REDACAO")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.TotalP)
                    .HasColumnName("TOTAL_P")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.TotalProva)
                    .HasColumnName("TOTAL_PROVA")
                    .HasColumnType("decimal(4,1)");
            });

            modelBuilder.Entity<CentroCusto>(entity =>
            {
                entity.HasKey(e => e.IdCc)
                    .HasName("PRIMARY");

                entity.ToTable("centro_custo");

                entity.HasIndex(e => new { e.CentroCusto1, e.Situacao })
                    .HasName("CENTROCUSTO");

                entity.HasIndex(e => new { e.Tipo, e.CentroCusto1, e.Situacao })
                    .HasName("TIPO");

                entity.Property(e => e.IdCc)
                    .HasColumnName("ID_CC")
                    .ValueGeneratedNever();

                entity.Property(e => e.CentroCusto1)
                    .HasColumnName("CENTRO_CUSTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo)
                    .HasColumnName("TIPO")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Cidades>(entity =>
            {
                entity.HasKey(e => e.IdCidade)
                    .HasName("PRIMARY");

                entity.ToTable("cidades");

                entity.Property(e => e.IdCidade)
                    .HasColumnName("ID_CIDADE")
                    .ValueGeneratedNever();

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Uf)
                    .HasColumnName("UF")
                    .HasColumnType("char(2)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<ContParametrosIni>(entity =>
            {
                entity.HasKey(e => new { e.Secao, e.Identificador })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("cont_parametros_ini");

                entity.Property(e => e.Secao)
                    .HasColumnName("SECAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Identificador)
                    .HasColumnName("IDENTIFICADOR")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("text")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<ContaCorrente>(entity =>
            {
                entity.HasKey(e => new { e.IdConta, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("conta_corrente");

                entity.HasIndex(e => e.IdUnidade)
                    .HasName("FK_REFERENCE_18");

                entity.Property(e => e.IdConta).HasColumnName("ID_CONTA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Agencia).HasColumnName("AGENCIA");

                entity.Property(e => e.Banco).HasColumnName("BANCO");

                entity.Property(e => e.Conta)
                    .HasColumnName("CONTA")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.HasOne(d => d.IdUnidadeNavigation)
                    .WithMany(p => p.ContaCorrente)
                    .HasForeignKey(d => d.IdUnidade)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_18");
            });

            modelBuilder.Entity<ContatoProspect>(entity =>
            {
                entity.HasKey(e => new { e.IdProspect, e.IdUnidade, e.IdContato })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("contato_prospect");

                entity.Property(e => e.IdProspect).HasColumnName("ID_PROSPECT");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdContato).HasColumnName("ID_CONTATO");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(255)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<DescricaoPgto>(entity =>
            {
                entity.HasKey(e => new { e.IdRecibo, e.IdUnidade, e.Seq })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("descricao_pgto");

                entity.Property(e => e.IdRecibo).HasColumnName("ID_RECIBO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Seq).HasColumnName("SEQ");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("text")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<DiaTurma>(entity =>
            {
                entity.HasKey(e => new { e.IdTurma, e.IdUnidade, e.Dia, e.Inicio })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0, 0 });

                entity.ToTable("dia_turma");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Dia).HasColumnName("DIA");

                entity.Property(e => e.Inicio)
                    .HasColumnName("INICIO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Fim)
                    .HasColumnName("FIM")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.Id)
                    .WithMany(p => p.DiaTurma)
                    .HasForeignKey(d => new { d.IdTurma, d.IdUnidade })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_6");
            });

            modelBuilder.Entity<Disponibilidade>(entity =>
            {
                entity.HasKey(e => new { e.IdProfessor, e.Dia, e.Inicio })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("disponibilidade");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");

                entity.Property(e => e.Dia).HasColumnName("DIA");

                entity.Property(e => e.Inicio)
                    .HasColumnName("INICIO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Fim)
                    .HasColumnName("FIM")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.IdProfessorNavigation)
                    .WithMany(p => p.Disponibilidade)
                    .HasForeignKey(d => d.IdProfessor)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_9");
            });

            modelBuilder.Entity<FecMovBancario>(entity =>
            {
                entity.HasKey(e => new { e.IdConta, e.IdUnidade, e.Data })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("fec_mov_bancario");

                entity.Property(e => e.IdConta).HasColumnName("ID_CONTA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(16,2)");
            });

            modelBuilder.Entity<FechamentoCaixa>(entity =>
            {
                entity.HasKey(e => new { e.IdFechamento, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("fechamento_caixa");

                entity.HasIndex(e => new { e.IdMov, e.IdUnidade })
                    .HasName("MOVIMENTOBANCO");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.ChequesPag)
                    .HasColumnName("CHEQUES_PAG")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.ChequesRec)
                    .HasColumnName("CHEQUES_REC")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DataHora)
                    .HasColumnName("DATA_HORA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Depositos)
                    .HasColumnName("DEPOSITOS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DinheiroPag)
                    .HasColumnName("DINHEIRO_PAG")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DinheiroRec)
                    .HasColumnName("DINHEIRO_REC")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.IdMov).HasColumnName("ID_MOV");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.QtdChequesPag).HasColumnName("QTD_CHEQUES_PAG");

                entity.Property(e => e.QtdChequesRec).HasColumnName("QTD_CHEQUES_REC");

                entity.Property(e => e.Saldo)
                    .HasColumnName("SALDO")
                    .HasColumnType("decimal(16,2)");
            });

            modelBuilder.Entity<FechamentoCaixaTmp>(entity =>
            {
                entity.HasKey(e => new { e.IdFechamento, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("fechamento_caixa_tmp");

                entity.HasIndex(e => new { e.IdOperador, e.IdMov, e.IdUnidade })
                    .HasName("MOVIMENTOBANCO");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.ChequesPag)
                    .HasColumnName("CHEQUES_PAG")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.ChequesRec)
                    .HasColumnName("CHEQUES_REC")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DataHora)
                    .HasColumnName("DATA_HORA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Depositos)
                    .HasColumnName("DEPOSITOS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DinheiroPag)
                    .HasColumnName("DINHEIRO_PAG")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.DinheiroRec)
                    .HasColumnName("DINHEIRO_REC")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.IdMov).HasColumnName("ID_MOV");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.QtdChequesPag).HasColumnName("QTD_CHEQUES_PAG");

                entity.Property(e => e.QtdChequesRec).HasColumnName("QTD_CHEQUES_REC");

                entity.Property(e => e.Saldo)
                    .HasColumnName("SALDO")
                    .HasColumnType("decimal(16,2)");
            });

            modelBuilder.Entity<FechamentoProduto>(entity =>
            {
                entity.HasKey(e => new { e.IdFechamento, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("fechamento_produto");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Feriados>(entity =>
            {
                entity.HasKey(e => e.Data)
                    .HasName("PRIMARY");

                entity.ToTable("feriados");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");
            });

            modelBuilder.Entity<FormaPgtoPar>(entity =>
            {
                entity.HasKey(e => new { e.IdRecibo, e.IdUnidade, e.Seq })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("forma_pgto_par");

                entity.HasIndex(e => new { e.IdFechamento, e.IdUnidade })
                    .HasName("FECHAMENTO");

                entity.Property(e => e.IdRecibo).HasColumnName("ID_RECIBO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Seq).HasColumnName("SEQ");

                entity.Property(e => e.Agencia).HasColumnName("AGENCIA");

                entity.Property(e => e.Banco).HasColumnName("BANCO");

                entity.Property(e => e.Conta)
                    .HasColumnName("CONTA")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataBaixa)
                    .HasColumnName("DATA_BAIXA")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataPgto)
                    .HasColumnName("DATA_PGTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Documento)
                    .HasColumnName("DOCUMENTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.FormaPgto).HasColumnName("FORMA_PGTO");

                entity.Property(e => e.IdConta).HasColumnName("ID_CONTA");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdUnidadeC).HasColumnName("ID_UNIDADE_C");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.ObsBaixa)
                    .HasColumnName("OBS_BAIXA")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.OpBaixa)
                    .HasColumnName("OP_BAIXA")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.PreDatado).HasColumnName("PRE_DATADO");

                entity.Property(e => e.TipoBaixa).HasColumnName("TIPO_BAIXA");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(10,2)");
            });

            modelBuilder.Entity<Fornecedores>(entity =>
            {
                entity.HasKey(e => e.Cnpj)
                    .HasName("PRIMARY");

                entity.ToTable("fornecedores");

                entity.Property(e => e.Cnpj)
                    .HasColumnName("CNPJ")
                    .HasColumnType("varchar(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Bairro)
                    .HasColumnName("BAIRRO")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cep)
                    .HasColumnName("CEP")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Complemento)
                    .HasColumnName("COMPLEMENTO")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.EMail)
                    .HasColumnName("E_MAIL")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Endereco)
                    .HasColumnName("ENDERECO")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdCidade).HasColumnName("ID_CIDADE");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Numero)
                    .HasColumnName("NUMERO")
                    .HasColumnType("varchar(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Telefone)
                    .HasColumnName("TELEFONE")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<GrupoProdutos>(entity =>
            {
                entity.HasKey(e => e.Codigo)
                    .HasName("PRIMARY");

                entity.ToTable("grupo_produtos");

                entity.Property(e => e.Codigo)
                    .HasColumnName("CODIGO")
                    .HasColumnType("varchar(4)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Habilitado>(entity =>
            {
                entity.HasKey(e => new { e.IdProfessor, e.IdNivel })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("habilitado");

                entity.HasIndex(e => e.IdNivel)
                    .HasName("FK_REFERENCE_8");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");

                entity.Property(e => e.IdNivel).HasColumnName("ID_NIVEL");

                entity.HasOne(d => d.IdNivelNavigation)
                    .WithMany(p => p.Habilitado)
                    .HasForeignKey(d => d.IdNivel)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_8");

                entity.HasOne(d => d.IdProfessorNavigation)
                    .WithMany(p => p.Habilitado)
                    .HasForeignKey(d => d.IdProfessor)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_7");
            });

            modelBuilder.Entity<HistoricoLotenfe>(entity =>
            {
                entity.HasKey(e => e.IdHistorico)
                    .HasName("PRIMARY");

                entity.ToTable("historico_lotenfe");

                entity.HasIndex(e => e.IdLote)
                    .HasName("FK_HISTORIC_REFERENCE_LOTES_NF");

                entity.Property(e => e.IdHistorico)
                    .HasColumnName("ID_HISTORICO")
                    .ValueGeneratedNever();

                entity.Property(e => e.DataEvento)
                    .HasColumnName("DATA_EVENTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdLote).HasColumnName("ID_LOTE");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.XmlRetorno)
                    .HasColumnName("XML_RETORNO")
                    .HasColumnType("text")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.HasOne(d => d.IdLoteNavigation)
                    .WithMany(p => p.HistoricoLotenfe)
                    .HasForeignKey(d => d.IdLote)
                    .HasConstraintName("FK_HISTORIC_REFERENCE_LOTES_NF");
            });

            modelBuilder.Entity<Idiomas>(entity =>
            {
                entity.HasKey(e => e.IdIdioma)
                    .HasName("PRIMARY");

                entity.ToTable("idiomas");

                entity.Property(e => e.IdIdioma)
                    .HasColumnName("ID_IDIOMA")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Inventario>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdProduto })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("inventario");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Qtd)
                    .HasColumnName("QTD")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<ItensFecProduto>(entity =>
            {
                entity.HasKey(e => new { e.IdFechamento, e.IdUnidade, e.IdProduto })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("itens_fec_produto");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Qtd)
                    .HasColumnName("QTD")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<ItensNfEntrada>(entity =>
            {
                entity.HasKey(e => new { e.IdNf, e.IdUnidade, e.IdProduto })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("itens_nf_entrada");

                entity.Property(e => e.IdNf).HasColumnName("ID_NF");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Qtd)
                    .HasColumnName("QTD")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.ValorU)
                    .HasColumnName("VALOR_U")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<ItensPedido>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdPedido, e.IdProduto })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("itens_pedido");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdPedido).HasColumnName("ID_PEDIDO");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.QtdR)
                    .HasColumnName("QTD_R")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.QtdS)
                    .HasColumnName("QTD_S")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.ValorU)
                    .HasColumnName("VALOR_U")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<LctoInventario>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdProduto, e.Data })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("lcto_inventario");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Qtd)
                    .HasColumnName("QTD")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");
            });

            modelBuilder.Entity<LogAtividades>(entity =>
            {
                entity.HasKey(e => new { e.IdLog, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("log_atividades");

                entity.Property(e => e.IdLog).HasColumnName("ID_LOG");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.DataHora)
                    .HasColumnName("DATA_HORA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Identificador)
                    .HasColumnName("IDENTIFICADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Rotina)
                    .HasColumnName("ROTINA")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<LotesNfe>(entity =>
            {
                entity.HasKey(e => e.IdLote)
                    .HasName("PRIMARY");

                entity.ToTable("lotes_nfe");

                entity.Property(e => e.IdLote)
                    .HasColumnName("ID_LOTE")
                    .ValueGeneratedNever();

                entity.Property(e => e.DataLote)
                    .HasColumnName("DATA_LOTE")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProtocoloLote)
                    .HasColumnName("PROTOCOLO_LOTE")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.QtdNfe).HasColumnName("QTD_NFE");

                entity.Property(e => e.XmlRemessa)
                    .HasColumnName("XML_REMESSA")
                    .HasColumnType("text")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Matricula>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdMatricula })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("matricula");

                entity.HasIndex(e => new { e.IdAluno, e.IdUnidade })
                    .HasName("ALUNO");

                entity.HasIndex(e => new { e.Tipo, e.IdTurma, e.IdUnidade })
                    .HasName("TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdMatricula).HasColumnName("ID_MATRICULA");

                entity.Property(e => e.DataMatricula)
                    .HasColumnName("DATA_MATRICULA")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdAluno).HasColumnName("ID_ALUNO");

                entity.Property(e => e.IdAluno2).HasColumnName("ID_ALUNO2");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.Nivel).HasColumnName("NIVEL");

                entity.Property(e => e.Obs)
                    .HasColumnName("OBS")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");
            });

            modelBuilder.Entity<MovBancario>(entity =>
            {
                entity.HasKey(e => new { e.IdMov, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("mov_bancario");

                entity.HasIndex(e => new { e.IdConta, e.IdUnidade, e.Data })
                    .HasName("CONTA");

                entity.Property(e => e.IdMov).HasColumnName("ID_MOV");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataLcto)
                    .HasColumnName("DATA_LCTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Documento)
                    .HasColumnName("DOCUMENTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Historico)
                    .HasColumnName("HISTORICO")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdCc).HasColumnName("ID_CC");

                entity.Property(e => e.IdConta).HasColumnName("ID_CONTA");

                entity.Property(e => e.IdUnidadeC).HasColumnName("ID_UNIDADE_C");

                entity.Property(e => e.Tipo)
                    .HasColumnName("TIPO")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Tiporeg).HasColumnName("TIPOREG");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.Vencimento)
                    .HasColumnName("VENCIMENTO")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<NfEntrada>(entity =>
            {
                entity.HasKey(e => new { e.IdNf, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("nf_entrada");

                entity.Property(e => e.IdNf).HasColumnName("ID_NF");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Cnpj)
                    .HasColumnName("CNPJ")
                    .HasColumnType("varchar(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Desconto)
                    .HasColumnName("DESCONTO")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.Frete)
                    .HasColumnName("FRETE")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Numero).HasColumnName("NUMERO");

                entity.Property(e => e.Outros)
                    .HasColumnName("OUTROS")
                    .HasColumnType("decimal(12,2)");

                entity.Property(e => e.Serie)
                    .HasColumnName("SERIE")
                    .HasColumnType("varchar(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<NfSaidas>(entity =>
            {
                entity.HasKey(e => new { e.IdNfSaidas, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("nf_saidas");

                entity.HasIndex(e => e.ChaveDanfe)
                    .HasName("CHAVE_DANFE");

                entity.HasIndex(e => e.NumeroNf)
                    .HasName("NUMERO_NF");

                entity.HasIndex(e => new { e.DataNf, e.Especie, e.Situacao, e.IdUnidade, e.IdCfo })
                    .HasName("DATA_NF");

                entity.Property(e => e.IdNfSaidas).HasColumnName("ID_NF_SAIDAS");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.AliquotaCofins).HasColumnName("ALIQUOTA_COFINS");

                entity.Property(e => e.AliquotaCssl).HasColumnName("ALIQUOTA_CSSL");

                entity.Property(e => e.AliquotaIrrf).HasColumnName("ALIQUOTA_IRRF");

                entity.Property(e => e.AliquotaIss)
                    .HasColumnName("ALIQUOTA_ISS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.AliquotaPis).HasColumnName("ALIQUOTA_PIS");

                entity.Property(e => e.AliquotaRet).HasColumnName("ALIQUOTA_RET");

                entity.Property(e => e.BaseCalculoIss)
                    .HasColumnName("BASE_CALCULO_ISS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.ChaveDanfe)
                    .HasColumnName("CHAVE_DANFE")
                    .HasColumnType("char(44)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.CnpjCliente)
                    .HasColumnName("CNPJ_CLIENTE")
                    .HasColumnType("char(14)")
                    .HasComment("Código do Cliente")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataNf)
                    .HasColumnName("DATA_NF")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataSaida)
                    .HasColumnName("DATA_SAIDA")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataSituacao)
                    .HasColumnName("DATA_SITUACAO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Especie)
                    .HasColumnName("ESPECIE")
                    .HasColumnType("char(2)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Exportado).HasColumnName("EXPORTADO");

                entity.Property(e => e.IdCfo)
                    .HasColumnName("ID_CFO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdLote).HasColumnName("ID_LOTE");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdTributacao).HasColumnName("ID_TRIBUTACAO");

                entity.Property(e => e.ImpostoAprox)
                    .HasColumnName("IMPOSTO_APROX")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.JustCancelamento)
                    .HasColumnName("JUST_CANCELAMENTO")
                    .HasColumnType("char(200)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.NumeroNf).HasColumnName("NUMERO_NF");

                entity.Property(e => e.ProtocoloNfe)
                    .HasColumnName("PROTOCOLO_NFE")
                    .HasColumnType("char(15)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.ReciboCancel)
                    .HasColumnName("RECIBO_CANCEL")
                    .HasColumnType("char(15)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.ReciboNfe)
                    .HasColumnName("RECIBO_NFE")
                    .HasColumnType("char(40)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.SerieNf)
                    .HasColumnName("SERIE_NF")
                    .HasColumnType("char(5)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.TotalCofins).HasColumnName("TOTAL_COFINS");

                entity.Property(e => e.TotalCssl).HasColumnName("TOTAL_CSSL");

                entity.Property(e => e.TotalInss).HasColumnName("TOTAL_INSS");

                entity.Property(e => e.TotalIrrf).HasColumnName("TOTAL_IRRF");

                entity.Property(e => e.TotalIss)
                    .HasColumnName("TOTAL_ISS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.TotalNf)
                    .HasColumnName("TOTAL_NF")
                    .HasColumnType("decimal(16,2)")
                    .HasDefaultValueSql("'0.00'");

                entity.Property(e => e.TotalPis).HasColumnName("TOTAL_PIS");

                entity.Property(e => e.TotalRet).HasColumnName("TOTAL_RET");
            });

            modelBuilder.Entity<Nivel>(entity =>
            {
                entity.HasKey(e => e.IdNivel)
                    .HasName("PRIMARY");

                entity.ToTable("nivel");

                entity.HasIndex(e => e.IdIdioma)
                    .HasName("FK_REFERENCE_2");

                entity.Property(e => e.IdNivel)
                    .HasColumnName("ID_NIVEL")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdIdioma).HasColumnName("ID_IDIOMA");

                entity.Property(e => e.Nivel1).HasColumnName("NIVEL");

                entity.Property(e => e.Seq).HasColumnName("SEQ");

                entity.Property(e => e.ValorMatAnual)
                    .HasColumnName("VALOR_MAT_ANUAL")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.ValorMaterial)
                    .HasColumnName("VALOR_MATERIAL")
                    .HasColumnType("decimal(10,2)");

                entity.HasOne(d => d.IdIdiomaNavigation)
                    .WithMany(p => p.Nivel)
                    .HasForeignKey(d => d.IdIdioma)
                    .HasConstraintName("FK_REFERENCE_2");
            });

            modelBuilder.Entity<Numeracoes>(entity =>
            {
                entity.HasKey(e => e.Entidade)
                    .HasName("PRIMARY");

                entity.ToTable("numeracoes");

                entity.Property(e => e.Entidade)
                    .HasColumnName("ENTIDADE")
                    .HasColumnType("char(18)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdCorrente).HasColumnName("ID_CORRENTE");
            });

            modelBuilder.Entity<Operador>(entity =>
            {
                entity.HasKey(e => e.IdOperador)
                    .HasName("PRIMARY");

                entity.ToTable("operador");

                entity.HasIndex(e => e.IdPerfil)
                    .HasName("FK_REFERENCE_15");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdPerfil).HasColumnName("ID_PERFIL");

                entity.Property(e => e.Senha)
                    .HasColumnName("SENHA")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.HasOne(d => d.IdPerfilNavigation)
                    .WithMany(p => p.Operador)
                    .HasForeignKey(d => d.IdPerfil)
                    .HasConstraintName("FK_REFERENCE_15");
            });

            modelBuilder.Entity<ParametrosIni>(entity =>
            {
                entity.HasKey(e => new { e.Secao, e.Identificador })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("parametros_ini");

                entity.Property(e => e.Secao)
                    .HasColumnName("SECAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Identificador)
                    .HasColumnName("IDENTIFICADOR")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cont).HasColumnName("CONT");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<ParametrosUnidade>(entity =>
            {
                entity.HasKey(e => e.IdUnidade)
                    .HasName("PRIMARY");

                entity.ToTable("parametros_unidade");

                entity.Property(e => e.IdUnidade)
                    .HasColumnName("ID_UNIDADE")
                    .ValueGeneratedNever();

                entity.Property(e => e.AliquotaInss)
                    .HasColumnName("ALIQUOTA_INSS")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.AliquotaIrrf)
                    .HasColumnName("ALIQUOTA_IRRF")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.AliquotaIss)
                    .HasColumnName("ALIQUOTA_ISS")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.AliquotaPcc)
                    .HasColumnName("ALIQUOTA_PCC")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.AmbienteNfse).HasColumnName("AMBIENTE_NFSE");

                entity.Property(e => e.Bairro)
                    .HasColumnName("BAIRRO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cep)
                    .HasColumnName("CEP")
                    .HasColumnType("char(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cnae)
                    .HasColumnName("CNAE")
                    .HasColumnType("char(15)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cnpj)
                    .HasColumnName("CNPJ")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.CodigoTributacao)
                    .HasColumnName("CODIGO_TRIBUTACAO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Complemento)
                    .HasColumnName("COMPLEMENTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Endereco)
                    .HasColumnName("ENDERECO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdCidade).HasColumnName("ID_CIDADE");

                entity.Property(e => e.Im)
                    .HasColumnName("IM")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Numero)
                    .HasColumnName("NUMERO")
                    .HasColumnType("char(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.PercBaseInss)
                    .HasColumnName("PERC_BASE_INSS")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.RazaoSocial)
                    .HasColumnName("RAZAO_SOCIAL")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.SenhaWsnfse)
                    .HasColumnName("SENHA_WSNFSE")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.SerieNf)
                    .HasColumnName("SERIE_NF")
                    .HasColumnType("char(4)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.SimplesNacional).HasColumnName("SIMPLES_NACIONAL");

                entity.Property(e => e.SnCertificado)
                    .HasColumnName("SN_CERTIFICADO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Telefone)
                    .HasColumnName("TELEFONE")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.UsuarioWsnfse)
                    .HasColumnName("USUARIO_WSNFSE")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.HasOne(d => d.IdUnidadeNavigation)
                    .WithOne(p => p.ParametrosUnidade)
                    .HasForeignKey<ParametrosUnidade>(d => d.IdUnidade)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_22");
            });

            modelBuilder.Entity<Parcelas>(entity =>
            {
                entity.HasKey(e => new { e.IdParcela, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("parcelas");

                entity.HasIndex(e => new { e.IdNfSaidas, e.IdUnidade })
                    .HasName("NF");

                entity.HasIndex(e => new { e.IdRecibo, e.IdUnidade })
                    .HasName("RECIBO");

                entity.HasIndex(e => new { e.IdUnidade, e.IdParcelaO })
                    .HasName("RESIDUO");

                entity.HasIndex(e => new { e.Vencimento, e.Situacao })
                    .HasName("VENCIMENTO");

                entity.HasIndex(e => new { e.IdUnidade, e.IdMatricula, e.Vencimento, e.Situacao })
                    .HasName("MATRICULA");

                entity.Property(e => e.IdParcela).HasColumnName("ID_PARCELA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.CpfcnpjResp)
                    .HasColumnName("CPFCNPJ_RESP")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataLcto)
                    .HasColumnName("DATA_LCTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Historico)
                    .HasColumnName("HISTORICO")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdMatricula).HasColumnName("ID_MATRICULA");

                entity.Property(e => e.IdNfSaidas).HasColumnName("ID_NF_SAIDAS");

                entity.Property(e => e.IdOperadoI)
                    .HasColumnName("ID_OPERADO_I")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdParcelaO).HasColumnName("ID_PARCELA_O");

                entity.Property(e => e.IdRecibo).HasColumnName("ID_RECIBO");

                entity.Property(e => e.Origem).HasColumnName("ORIGEM");

                entity.Property(e => e.Seq).HasColumnName("SEQ");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo)
                    .HasColumnName("TIPO")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Vencimento)
                    .HasColumnName("VENCIMENTO")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Pedido>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdPedido })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("pedido");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdPedido).HasColumnName("ID_PEDIDO");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataEntrega)
                    .HasColumnName("DATA_ENTREGA")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdAlmox).HasColumnName("ID_ALMOX");

                entity.Property(e => e.IdOpEntrega)
                    .HasColumnName("ID_OP_ENTREGA")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdPedidoO).HasColumnName("ID_PEDIDO_O");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.TipoPgto).HasColumnName("TIPO_PGTO");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<PerfilOp>(entity =>
            {
                entity.HasKey(e => e.IdPerfil)
                    .HasName("PRIMARY");

                entity.ToTable("perfil_op");

                entity.Property(e => e.IdPerfil)
                    .HasColumnName("ID_PERFIL")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<PermissoesPerfil>(entity =>
            {
                entity.HasKey(e => new { e.IdPerfil, e.Identificador })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("permissoes_perfil");

                entity.Property(e => e.IdPerfil).HasColumnName("ID_PERFIL");

                entity.Property(e => e.Identificador).HasColumnName("IDENTIFICADOR");

                entity.Property(e => e.Alterar)
                    .HasColumnName("ALTERAR")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Ativo)
                    .HasColumnName("ATIVO")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Excluir)
                    .HasColumnName("EXCLUIR")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Incluir)
                    .HasColumnName("INCLUIR")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.HasOne(d => d.IdPerfilNavigation)
                    .WithMany(p => p.PermissoesPerfil)
                    .HasForeignKey(d => d.IdPerfil)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_17");
            });

            modelBuilder.Entity<PgtoMat>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdMatricula, e.Seq })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("pgto_mat");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdMatricula).HasColumnName("ID_MATRICULA");

                entity.Property(e => e.Seq).HasColumnName("SEQ");

                entity.Property(e => e.Convenio).HasColumnName("CONVENIO");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Desconto)
                    .HasColumnName("DESCONTO")
                    .HasColumnType("decimal(4,1)");

                entity.Property(e => e.MotDesconto)
                    .HasColumnName("MOT_DESCONTO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.NomeConvenio)
                    .HasColumnName("NOME_CONVENIO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.QtdAula)
                    .HasColumnName("QTD_AULA")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.ValorHora)
                    .HasColumnName("VALOR_HORA")
                    .HasColumnType("decimal(10,2)");
            });

            modelBuilder.Entity<PrecoProduto>(entity =>
            {
                entity.HasKey(e => e.IdProduto)
                    .HasName("PRIMARY");

                entity.ToTable("preco_produto");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("char(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Validade)
                    .HasColumnName("VALIDADE")
                    .HasColumnType("datetime");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<Precos>(entity =>
            {
                entity.HasKey(e => new { e.Validade, e.Tipo })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("precos");

                entity.Property(e => e.Validade)
                    .HasColumnName("VALIDADE")
                    .HasColumnType("datetime");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.Avancado)
                    .HasColumnName("AVANCADO")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Basico)
                    .HasColumnName("BASICO")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Convenio)
                    .HasColumnName("CONVENIO")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Dupla)
                    .HasColumnName("DUPLA")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Individual)
                    .HasColumnName("INDIVIDUAL")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.Intermediario)
                    .HasColumnName("INTERMEDIARIO")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.PacoteDup)
                    .HasColumnName("PACOTE_DUP")
                    .HasColumnType("decimal(10,2)");

                entity.Property(e => e.PacoteInd)
                    .HasColumnName("PACOTE_IND")
                    .HasColumnType("decimal(10,2)");
            });

            modelBuilder.Entity<Produto>(entity =>
            {
                entity.HasKey(e => e.IdProduto)
                    .HasName("PRIMARY");

                entity.ToTable("produto");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("varchar(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.CodigoP)
                    .HasColumnName("CODIGO_P")
                    .HasColumnType("varchar(4)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Ordem).HasColumnName("ORDEM");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");
            });

            modelBuilder.Entity<Professor>(entity =>
            {
                entity.HasKey(e => e.IdProfessor)
                    .HasName("PRIMARY");

                entity.ToTable("professor");

                entity.Property(e => e.IdProfessor)
                    .HasColumnName("ID_PROFESSOR")
                    .ValueGeneratedNever();

                entity.Property(e => e.HoraAula)
                    .HasColumnName("HORA_AULA")
                    .HasColumnType("decimal(12,4)");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Telefone)
                    .HasColumnName("TELEFONE")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Telefone2)
                    .HasColumnName("TELEFONE2")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<ProfessorTurma>(entity =>
            {
                entity.HasKey(e => new { e.IdTurma, e.IdUnidade, e.Sequencia })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("professor_turma");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Sequencia).HasColumnName("SEQUENCIA");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");
            });

            modelBuilder.Entity<ProfessoresTurma>(entity =>
            {
                entity.HasKey(e => new { e.IdTurma, e.IdUnidade, e.Sequencia })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("professores_turma");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Sequencia).HasColumnName("SEQUENCIA");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");
            });

            modelBuilder.Entity<Prospect>(entity =>
            {
                entity.HasKey(e => new { e.IdProspect, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("prospect");

                entity.Property(e => e.IdProspect).HasColumnName("ID_PROSPECT");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Celular)
                    .HasColumnName("CELULAR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataCadastro)
                    .HasColumnName("DATA_CADASTRO")
                    .HasColumnType("datetime");

                entity.Property(e => e.DataTeste)
                    .HasColumnName("DATA_TESTE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DispHorario)
                    .HasColumnName("DISP_HORARIO")
                    .HasColumnType("char(250)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.EMail)
                    .HasColumnName("E_MAIL")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.FormaConh).HasColumnName("FORMA_CONH");

                entity.Property(e => e.IdIdioma).HasColumnName("ID_IDIOMA");

                entity.Property(e => e.Interesse)
                    .HasColumnName("INTERESSE")
                    .HasColumnType("char(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.JaEstudou).HasColumnName("JA_ESTUDOU");

                entity.Property(e => e.Nascimento)
                    .HasColumnName("NASCIMENTO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Nivel).HasColumnName("NIVEL");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Telefone)
                    .HasColumnName("TELEFONE")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Tempo)
                    .HasColumnName("TEMPO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.UltimoContato)
                    .HasColumnName("ULTIMO_CONTATO")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<ProvdescProf>(entity =>
            {
                entity.HasKey(e => new { e.IdProfessor, e.IdUnidade, e.IdPd, e.Data })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0, 0 });

                entity.ToTable("provdesc_prof");

                entity.Property(e => e.IdProfessor).HasColumnName("ID_PROFESSOR");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdPd).HasColumnName("ID_PD");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<ProventosDesc>(entity =>
            {
                entity.HasKey(e => e.IdPd)
                    .HasName("PRIMARY");

                entity.ToTable("proventos_desc");

                entity.Property(e => e.IdPd)
                    .HasColumnName("ID_PD")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<Recibo>(entity =>
            {
                entity.HasKey(e => new { e.IdRecibo, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("recibo");

                entity.Property(e => e.IdRecibo).HasColumnName("ID_RECIBO");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Data)
                    .HasColumnName("DATA")
                    .HasColumnType("datetime");

                entity.Property(e => e.Desconto)
                    .HasColumnName("DESCONTO")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.Enviado).HasColumnName("ENVIADO");

                entity.Property(e => e.IdFechamento).HasColumnName("ID_FECHAMENTO");

                entity.Property(e => e.IdOperador)
                    .HasColumnName("ID_OPERADOR")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Juros)
                    .HasColumnName("JUROS")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.Tipo)
                    .HasColumnName("TIPO")
                    .HasColumnType("char(1)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(16,2)");

                entity.Property(e => e.ValorLiq)
                    .HasColumnName("VALOR_LIQ")
                    .HasColumnType("decimal(16,2)");
            });

            modelBuilder.Entity<RespFinanceiro>(entity =>
            {
                entity.HasKey(e => e.CpfcnpjResp)
                    .HasName("PRIMARY");

                entity.ToTable("resp_financeiro");

                entity.Property(e => e.CpfcnpjResp)
                    .HasColumnName("CPFCNPJ_RESP")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Bairro)
                    .HasColumnName("BAIRRO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cep)
                    .HasColumnName("CEP")
                    .HasColumnType("char(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Cidade)
                    .HasColumnName("CIDADE")
                    .HasColumnType("char(30)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Complemento)
                    .HasColumnName("COMPLEMENTO")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.DataCadastro)
                    .HasColumnName("DATA_CADASTRO")
                    .HasColumnType("datetime");

                entity.Property(e => e.EMail)
                    .HasColumnName("E_MAIL")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Endereco)
                    .HasColumnName("ENDERECO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Fax)
                    .HasColumnName("FAX")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdCidade).HasColumnName("ID_CIDADE");

                entity.Property(e => e.Iest)
                    .HasColumnName("IEST")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Imun)
                    .HasColumnName("IMUN")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Nome)
                    .HasColumnName("NOME")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Numero)
                    .HasColumnName("NUMERO")
                    .HasColumnType("char(10)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.PercRetIss)
                    .HasColumnName("PERC_RET_ISS")
                    .HasColumnType("decimal(5,2)");

                entity.Property(e => e.RetemInss).HasColumnName("RETEM_INSS");

                entity.Property(e => e.RetemIr).HasColumnName("RETEM_IR");

                entity.Property(e => e.RetemPcc).HasColumnName("RETEM_PCC");

                entity.Property(e => e.Tel1)
                    .HasColumnName("TEL_1")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Tel2)
                    .HasColumnName("TEL_2")
                    .HasColumnType("char(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Uf)
                    .HasColumnName("UF")
                    .HasColumnType("char(2)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            modelBuilder.Entity<RespMat>(entity =>
            {
                entity.HasKey(e => new { e.IdUnidade, e.IdMatricula, e.CpfcnpjResp })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

                entity.ToTable("resp_mat");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.IdMatricula).HasColumnName("ID_MATRICULA");

                entity.Property(e => e.CpfcnpjResp)
                    .HasColumnName("CPFCNPJ_RESP")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Perc)
                    .HasColumnName("PERC")
                    .HasColumnType("decimal(4,1)");

                entity.HasOne(d => d.Id)
                    .WithMany(p => p.RespMat)
                    .HasForeignKey(d => new { d.IdUnidade, d.IdMatricula })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_21");
            });

            modelBuilder.Entity<Sala>(entity =>
            {
                entity.HasKey(e => new { e.IdSala, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("sala");

                entity.HasIndex(e => e.IdUnidade)
                    .HasName("FK_REFERENCE_1");

                entity.Property(e => e.IdSala).HasColumnName("ID_SALA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.HasOne(d => d.IdUnidadeNavigation)
                    .WithMany(p => p.Sala)
                    .HasForeignKey(d => d.IdUnidade)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_1");
            });

            modelBuilder.Entity<SaldoProduto>(entity =>
            {
                entity.HasKey(e => new { e.IdProduto, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("saldo_produto");

                entity.Property(e => e.IdProduto)
                    .HasColumnName("ID_PRODUTO")
                    .HasColumnType("char(8)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Local)
                    .HasColumnName("LOCAL")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Qtd)
                    .HasColumnName("QTD")
                    .HasColumnType("decimal(12,2)");
            });

            modelBuilder.Entity<TipoTarifa>(entity =>
            {
                entity.HasKey(e => e.IdTarifa)
                    .HasName("PRIMARY");

                entity.ToTable("tipo_tarifa");

                entity.Property(e => e.IdTarifa)
                    .HasColumnName("ID_TARIFA")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Valor)
                    .HasColumnName("VALOR")
                    .HasColumnType("decimal(12,4)");

                entity.Property(e => e.VlTraslado)
                    .HasColumnName("VL_TRASLADO")
                    .HasColumnType("decimal(10,2)");
            });

            modelBuilder.Entity<Turma>(entity =>
            {
                entity.HasKey(e => new { e.IdTurma, e.IdUnidade })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("turma");

                entity.HasIndex(e => e.IdNivel)
                    .HasName("FK_REFERENCE_4");

                entity.HasIndex(e => e.IdTarifa)
                    .HasName("FK_REFERENCE_14");

                entity.HasIndex(e => new { e.IdSala, e.IdUnidade })
                    .HasName("FK_REFERENCE_16");

                entity.HasIndex(e => new { e.CpfcnpjResp, e.IdTurma, e.IdUnidade })
                    .HasName("RESPONSAVEL");

                entity.Property(e => e.IdTurma).HasColumnName("ID_TURMA");

                entity.Property(e => e.IdUnidade).HasColumnName("ID_UNIDADE");

                entity.Property(e => e.Classificacao).HasColumnName("CLASSIFICACAO");

                entity.Property(e => e.CpfcnpjResp)
                    .HasColumnName("CPFCNPJ_RESP")
                    .HasColumnType("char(14)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Descturma)
                    .HasColumnName("DESCTURMA")
                    .HasColumnType("char(100)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");

                entity.Property(e => e.Fim)
                    .HasColumnName("FIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdNivel).HasColumnName("ID_NIVEL");

                entity.Property(e => e.IdProf1).HasColumnName("ID_PROF1");

                entity.Property(e => e.IdProf2).HasColumnName("ID_PROF2");

                entity.Property(e => e.IdSala).HasColumnName("ID_SALA");

                entity.Property(e => e.IdTarifa).HasColumnName("ID_TARIFA");

                entity.Property(e => e.IdTurmaR).HasColumnName("ID_TURMA_R");

                entity.Property(e => e.Inicio)
                    .HasColumnName("INICIO")
                    .HasColumnType("datetime");

                entity.Property(e => e.Situacao).HasColumnName("SITUACAO");

                entity.Property(e => e.Tipo).HasColumnName("TIPO");

                entity.HasOne(d => d.IdNivelNavigation)
                    .WithMany(p => p.Turma)
                    .HasForeignKey(d => d.IdNivel)
                    .HasConstraintName("FK_REFERENCE_4");

                entity.HasOne(d => d.IdTarifaNavigation)
                    .WithMany(p => p.Turma)
                    .HasForeignKey(d => d.IdTarifa)
                    .HasConstraintName("FK_REFERENCE_14");

                entity.HasOne(d => d.Id)
                    .WithMany(p => p.Turma)
                    .HasForeignKey(d => new { d.IdSala, d.IdUnidade })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_REFERENCE_16");
            });

            modelBuilder.Entity<Unidades>(entity =>
            {
                entity.HasKey(e => e.IdUnidade)
                    .HasName("PRIMARY");

                entity.ToTable("unidades");

                entity.Property(e => e.IdUnidade)
                    .HasColumnName("ID_UNIDADE")
                    .ValueGeneratedNever();

                entity.Property(e => e.Almox).HasColumnName("ALMOX");

                entity.Property(e => e.CodExt).HasColumnName("COD_EXT");

                entity.Property(e => e.Descricao)
                    .HasColumnName("DESCRICAO")
                    .HasColumnType("char(50)")
                    .HasCharSet("latin1")
                    .HasCollation("latin1_swedish_ci");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
