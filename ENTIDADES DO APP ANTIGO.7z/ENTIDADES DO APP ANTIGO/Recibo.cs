﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Recibo
    {
        public int IdRecibo { get; set; }
        public int IdUnidade { get; set; }
        public string Tipo { get; set; }
        public decimal? Valor { get; set; }
        public DateTime? Data { get; set; }
        public string IdOperador { get; set; }
        public int? IdFechamento { get; set; }
        public decimal? ValorLiq { get; set; }
        public int? Enviado { get; set; }
        public decimal? Juros { get; set; }
        public decimal? Desconto { get; set; }
    }
}
