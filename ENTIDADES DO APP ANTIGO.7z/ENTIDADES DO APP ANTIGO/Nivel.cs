﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Nivel
    {
        public Nivel()
        {
            Habilitado = new HashSet<Habilitado>();
            Turma = new HashSet<Turma>();
        }

        public int IdNivel { get; set; }
        public int? IdIdioma { get; set; }
        public string Descricao { get; set; }
        public int? Nivel1 { get; set; }
        public int? Seq { get; set; }
        public decimal? ValorMaterial { get; set; }
        public decimal? ValorMatAnual { get; set; }

        public virtual Idiomas IdIdiomaNavigation { get; set; }
        public virtual ICollection<Habilitado> Habilitado { get; set; }
        public virtual ICollection<Turma> Turma { get; set; }
    }
}
