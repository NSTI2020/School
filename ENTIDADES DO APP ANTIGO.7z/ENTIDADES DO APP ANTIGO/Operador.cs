﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Operador
    {
        public string IdOperador { get; set; }
        public int? IdPerfil { get; set; }
        public string Senha { get; set; }
        public int? Situacao { get; set; }

        public virtual PerfilOp IdPerfilNavigation { get; set; }
    }
}
