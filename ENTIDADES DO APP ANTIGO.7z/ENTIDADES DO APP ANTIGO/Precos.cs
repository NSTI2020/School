﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Precos
    {
        public DateTime Validade { get; set; }
        public int Tipo { get; set; }
        public decimal? Basico { get; set; }
        public decimal? Intermediario { get; set; }
        public decimal? Avancado { get; set; }
        public decimal? Individual { get; set; }
        public decimal? PacoteInd { get; set; }
        public decimal? Dupla { get; set; }
        public decimal? PacoteDup { get; set; }
        public decimal? Convenio { get; set; }
    }
}
