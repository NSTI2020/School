﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Feriados
    {
        public DateTime Data { get; set; }
        public int? Tipo { get; set; }
    }
}
