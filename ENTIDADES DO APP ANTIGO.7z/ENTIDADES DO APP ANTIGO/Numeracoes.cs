﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Numeracoes
    {
        public string Entidade { get; set; }
        public int? IdCorrente { get; set; }
    }
}
