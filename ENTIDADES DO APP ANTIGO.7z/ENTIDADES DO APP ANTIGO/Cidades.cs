﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Cidades
    {
        public int IdCidade { get; set; }
        public string Nome { get; set; }
        public string Uf { get; set; }
    }
}
