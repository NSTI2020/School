﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class RespMat
    {
        public int IdUnidade { get; set; }
        public int IdMatricula { get; set; }
        public string CpfcnpjResp { get; set; }
        public decimal? Perc { get; set; }

        public virtual Matricula Id { get; set; }
    }
}
