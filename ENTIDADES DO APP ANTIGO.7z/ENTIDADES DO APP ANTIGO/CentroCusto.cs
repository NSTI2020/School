﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class CentroCusto
    {
        public int IdCc { get; set; }
        public string CentroCusto1 { get; set; }
        public string Descricao { get; set; }
        public string Tipo { get; set; }
        public int? Situacao { get; set; }
    }
}
