﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class FechamentoCaixaTmp
    {
        public int IdFechamento { get; set; }
        public int IdUnidade { get; set; }
        public DateTime? DataHora { get; set; }
        public decimal? DinheiroRec { get; set; }
        public decimal? ChequesRec { get; set; }
        public int? QtdChequesRec { get; set; }
        public decimal? Depositos { get; set; }
        public decimal? ChequesPag { get; set; }
        public int? QtdChequesPag { get; set; }
        public decimal? DinheiroPag { get; set; }
        public decimal? Saldo { get; set; }
        public string IdOperador { get; set; }
        public int? IdMov { get; set; }
    }
}
