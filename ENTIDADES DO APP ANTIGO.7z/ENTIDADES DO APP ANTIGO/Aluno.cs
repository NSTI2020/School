﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Aluno
    {
        public int IdAluno { get; set; }
        public int IdUnidade { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Uf { get; set; }
        public string Cep { get; set; }
        public string TelRes { get; set; }
        public string TelCel { get; set; }
        public string TelCom { get; set; }
        public string Cpf { get; set; }
        public string Id { get; set; }
        public DateTime? DataCadastro { get; set; }
        public DateTime? Nascimento { get; set; }
        public int? Sexo { get; set; }
        public int? EstadoCivil { get; set; }
        public string EMail { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }

        public virtual Unidades IdUnidadeNavigation { get; set; }
    }
}
