﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ProventosDesc
    {
        public int IdPd { get; set; }
        public string Descricao { get; set; }
    }
}
