﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Parcelas
    {
        public int IdParcela { get; set; }
        public int IdUnidade { get; set; }
        public DateTime? DataLcto { get; set; }
        public DateTime? Vencimento { get; set; }
        public string Tipo { get; set; }
        public decimal? Valor { get; set; }
        public string Historico { get; set; }
        public int? Situacao { get; set; }
        public string IdOperadoI { get; set; }
        public int? IdMatricula { get; set; }
        public int? IdFechamento { get; set; }
        public string CpfcnpjResp { get; set; }
        public int? Seq { get; set; }
        public int? Origem { get; set; }
        public int? IdRecibo { get; set; }
        public int? IdParcelaO { get; set; }
        public int? IdNfSaidas { get; set; }
    }
}
