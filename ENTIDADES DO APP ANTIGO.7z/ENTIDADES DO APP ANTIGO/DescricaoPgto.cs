﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class DescricaoPgto
    {
        public int IdRecibo { get; set; }
        public int IdUnidade { get; set; }
        public int Seq { get; set; }
        public string Descricao { get; set; }
    }
}
