﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class GrupoProdutos
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }
    }
}
