﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class LogAtividades
    {
        public int IdLog { get; set; }
        public int IdUnidade { get; set; }
        public string Rotina { get; set; }
        public string Identificador { get; set; }
        public string IdOperador { get; set; }
        public DateTime? DataHora { get; set; }
        public string Descricao { get; set; }
    }
}
