﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class HistoricoLotenfe
    {
        public int IdHistorico { get; set; }
        public int? IdLote { get; set; }
        public int? Tipo { get; set; }
        public DateTime? DataEvento { get; set; }
        public string XmlRetorno { get; set; }

        public virtual LotesNfe IdLoteNavigation { get; set; }
    }
}
