﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class LctoInventario
    {
        public int IdUnidade { get; set; }
        public string IdProduto { get; set; }
        public DateTime Data { get; set; }
        public int? Tipo { get; set; }
        public decimal? Qtd { get; set; }
    }
}
