﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ParametrosIni
    {
        public string Secao { get; set; }
        public string Identificador { get; set; }
        public int? Tipo { get; set; }
        public string Valor { get; set; }
        public int? Cont { get; set; }
    }
}
