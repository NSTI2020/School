﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ItensPedido
    {
        public int IdUnidade { get; set; }
        public int IdPedido { get; set; }
        public string IdProduto { get; set; }
        public decimal? QtdS { get; set; }
        public decimal? QtdR { get; set; }
        public decimal? ValorU { get; set; }
        public decimal? Valor { get; set; }
        public int? Tipo { get; set; }
    }
}
