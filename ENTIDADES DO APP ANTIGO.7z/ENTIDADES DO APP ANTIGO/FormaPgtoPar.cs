﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class FormaPgtoPar
    {
        public int IdRecibo { get; set; }
        public int IdUnidade { get; set; }
        public int Seq { get; set; }
        public int? FormaPgto { get; set; }
        public int? Banco { get; set; }
        public int? Agencia { get; set; }
        public string Conta { get; set; }
        public string Documento { get; set; }
        public string Nome { get; set; }
        public DateTime? DataPgto { get; set; }
        public int? PreDatado { get; set; }
        public decimal? Valor { get; set; }
        public int? IdConta { get; set; }
        public int? IdUnidadeC { get; set; }
        public DateTime? DataBaixa { get; set; }
        public string OpBaixa { get; set; }
        public int? TipoBaixa { get; set; }
        public string ObsBaixa { get; set; }
        public int? IdFechamento { get; set; }
    }
}
