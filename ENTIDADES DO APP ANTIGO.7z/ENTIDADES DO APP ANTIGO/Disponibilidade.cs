﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Disponibilidade
    {
        public int IdProfessor { get; set; }
        public int Dia { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime? Fim { get; set; }

        public virtual Professor IdProfessorNavigation { get; set; }
    }
}
