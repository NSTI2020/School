﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class NfEntrada
    {
        public int IdNf { get; set; }
        public int IdUnidade { get; set; }
        public int? Numero { get; set; }
        public string Serie { get; set; }
        public string Cnpj { get; set; }
        public DateTime? Data { get; set; }
        public decimal? Valor { get; set; }
        public string IdOperador { get; set; }
        public decimal? Desconto { get; set; }
        public decimal? Frete { get; set; }
        public decimal? Outros { get; set; }
    }
}
