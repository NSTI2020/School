﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Turma
    {
        public Turma()
        {
            AulasDadas = new HashSet<AulasDadas>();
            DiaTurma = new HashSet<DiaTurma>();
        }

        public int IdTurma { get; set; }
        public int? IdNivel { get; set; }
        public int? IdTarifa { get; set; }
        public int IdSala { get; set; }
        public int IdUnidade { get; set; }
        public int? Tipo { get; set; }
        public int? IdProf1 { get; set; }
        public int? IdProf2 { get; set; }
        public DateTime? Inicio { get; set; }
        public DateTime? Fim { get; set; }
        public string Descturma { get; set; }
        public int? IdTurmaR { get; set; }
        public int? Classificacao { get; set; }
        public int? Situacao { get; set; }
        public string CpfcnpjResp { get; set; }
        public string Descricao { get; set; }

        public virtual Sala Id { get; set; }
        public virtual Nivel IdNivelNavigation { get; set; }
        public virtual TipoTarifa IdTarifaNavigation { get; set; }
        public virtual ICollection<AulasDadas> AulasDadas { get; set; }
        public virtual ICollection<DiaTurma> DiaTurma { get; set; }
    }
}
