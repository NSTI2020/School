﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Unidades
    {
        public Unidades()
        {
            Aluno = new HashSet<Aluno>();
            ContaCorrente = new HashSet<ContaCorrente>();
            Sala = new HashSet<Sala>();
        }

        public int IdUnidade { get; set; }
        public string Descricao { get; set; }
        public int? Almox { get; set; }
        public int? CodExt { get; set; }

        public virtual ParametrosUnidade ParametrosUnidade { get; set; }
        public virtual ICollection<Aluno> Aluno { get; set; }
        public virtual ICollection<ContaCorrente> ContaCorrente { get; set; }
        public virtual ICollection<Sala> Sala { get; set; }
    }
}
