﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Sala
    {
        public Sala()
        {
            Turma = new HashSet<Turma>();
        }

        public int IdSala { get; set; }
        public int IdUnidade { get; set; }
        public string Descricao { get; set; }

        public virtual Unidades IdUnidadeNavigation { get; set; }
        public virtual ICollection<Turma> Turma { get; set; }
    }
}
