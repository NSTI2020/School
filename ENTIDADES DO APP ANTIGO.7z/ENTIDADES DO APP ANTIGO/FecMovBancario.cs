﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class FecMovBancario
    {
        public int IdConta { get; set; }
        public int IdUnidade { get; set; }
        public DateTime Data { get; set; }
        public decimal? Valor { get; set; }
    }
}
