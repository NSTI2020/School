﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class PerfilOp
    {
        public PerfilOp()
        {
            Operador = new HashSet<Operador>();
            PermissoesPerfil = new HashSet<PermissoesPerfil>();
        }

        public int IdPerfil { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<Operador> Operador { get; set; }
        public virtual ICollection<PermissoesPerfil> PermissoesPerfil { get; set; }
    }
}
