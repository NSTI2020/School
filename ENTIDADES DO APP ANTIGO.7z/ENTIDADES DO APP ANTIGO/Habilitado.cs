﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Habilitado
    {
        public int IdProfessor { get; set; }
        public int IdNivel { get; set; }

        public virtual Nivel IdNivelNavigation { get; set; }
        public virtual Professor IdProfessorNavigation { get; set; }
    }
}
