﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Avaliacao
    {
        public int IdTurma { get; set; }
        public int IdUnidade { get; set; }
        public int IdMatricula { get; set; }
        public int Bimestre { get; set; }
        public int? AulasDadas { get; set; }
        public int? AulasAssistidas { get; set; }
        public int? Faltas { get; set; }
        public decimal? Comprometimento { get; set; }
        public decimal? AtivExtra { get; set; }
        public decimal? HabEst { get; set; }
        public decimal? Envolv { get; set; }
        public decimal? Inter { get; set; }
        public decimal? TotalP { get; set; }
        public decimal? ProvaE { get; set; }
        public decimal? CompAud { get; set; }
        public decimal? ProvaO { get; set; }
        public decimal? Redacao { get; set; }
        public decimal? TotalProva { get; set; }
    }
}
