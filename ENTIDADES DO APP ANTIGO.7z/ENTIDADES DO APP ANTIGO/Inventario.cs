﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Inventario
    {
        public int IdUnidade { get; set; }
        public DateTime? Data { get; set; }
        public string IdProduto { get; set; }
        public decimal? Qtd { get; set; }
    }
}
