﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ParametrosUnidade
    {
        public int IdUnidade { get; set; }
        public string Endereco { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public int? IdCidade { get; set; }
        public string Cep { get; set; }
        public string Telefone { get; set; }
        public int? AmbienteNfse { get; set; }
        public string UsuarioWsnfse { get; set; }
        public string SenhaWsnfse { get; set; }
        public int? SimplesNacional { get; set; }
        public string SnCertificado { get; set; }
        public string Cnpj { get; set; }
        public string Im { get; set; }
        public string Cnae { get; set; }
        public string CodigoTributacao { get; set; }
        public decimal? AliquotaIss { get; set; }
        public decimal? AliquotaIrrf { get; set; }
        public decimal? AliquotaPcc { get; set; }
        public decimal? AliquotaInss { get; set; }
        public decimal? PercBaseInss { get; set; }
        public string SerieNf { get; set; }
        public string RazaoSocial { get; set; }

        public virtual Unidades IdUnidadeNavigation { get; set; }
    }
}
