﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class SaldoProduto
    {
        public string IdProduto { get; set; }
        public int IdUnidade { get; set; }
        public string Local { get; set; }
        public decimal? Qtd { get; set; }
    }
}
