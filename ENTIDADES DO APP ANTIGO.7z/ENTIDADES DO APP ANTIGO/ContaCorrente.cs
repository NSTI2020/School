﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ContaCorrente
    {
        public int IdConta { get; set; }
        public int IdUnidade { get; set; }
        public int? Banco { get; set; }
        public int? Agencia { get; set; }
        public string Conta { get; set; }
        public int? Situacao { get; set; }
        public string Descricao { get; set; }

        public virtual Unidades IdUnidadeNavigation { get; set; }
    }
}
