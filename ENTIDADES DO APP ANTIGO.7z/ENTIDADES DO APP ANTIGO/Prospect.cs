﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Prospect
    {
        public int IdProspect { get; set; }
        public int IdUnidade { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
        public string Celular { get; set; }
        public string EMail { get; set; }
        public int? IdIdioma { get; set; }
        public int? JaEstudou { get; set; }
        public string Tempo { get; set; }
        public string DispHorario { get; set; }
        public int? FormaConh { get; set; }
        public string Interesse { get; set; }
        public DateTime? DataTeste { get; set; }
        public int? Nivel { get; set; }
        public DateTime? UltimoContato { get; set; }
        public int? Situacao { get; set; }
        public DateTime? Nascimento { get; set; }
        public DateTime? DataCadastro { get; set; }
    }
}
