﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Produto
    {
        public string IdProduto { get; set; }
        public string CodigoP { get; set; }
        public int? Ordem { get; set; }
        public string Descricao { get; set; }
        public int? Situacao { get; set; }
    }
}
