﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ProvdescProf
    {
        public int IdProfessor { get; set; }
        public int IdUnidade { get; set; }
        public int IdPd { get; set; }
        public DateTime Data { get; set; }
        public decimal? Valor { get; set; }
        public int? Tipo { get; set; }
    }
}
