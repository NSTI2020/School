﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Pedido
    {
        public int IdUnidade { get; set; }
        public int IdPedido { get; set; }
        public DateTime? Data { get; set; }
        public string IdOperador { get; set; }
        public int? Situacao { get; set; }
        public string IdOpEntrega { get; set; }
        public DateTime? DataEntrega { get; set; }
        public int? IdAlmox { get; set; }
        public int? IdPedidoO { get; set; }
        public decimal? Valor { get; set; }
        public int? Tipo { get; set; }
        public int? TipoPgto { get; set; }
    }
}
