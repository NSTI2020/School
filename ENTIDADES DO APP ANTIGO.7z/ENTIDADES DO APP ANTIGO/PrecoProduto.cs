﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class PrecoProduto
    {
        public string IdProduto { get; set; }
        public DateTime? Validade { get; set; }
        public decimal? Valor { get; set; }
    }
}
