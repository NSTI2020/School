﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ContParametrosIni
    {
        public string Secao { get; set; }
        public string Identificador { get; set; }
        public string Valor { get; set; }
    }
}
