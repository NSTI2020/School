﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class RespFinanceiro
    {
        public string CpfcnpjResp { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Uf { get; set; }
        public string Cep { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Fax { get; set; }
        public string Id { get; set; }
        public DateTime? DataCadastro { get; set; }
        public string EMail { get; set; }
        public string Iest { get; set; }
        public string Imun { get; set; }
        public int? RetemIr { get; set; }
        public int? RetemPcc { get; set; }
        public int? RetemInss { get; set; }
        public decimal? PercRetIss { get; set; }
        public int? IdCidade { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
    }
}
