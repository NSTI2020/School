﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ItensNfEntrada
    {
        public int IdNf { get; set; }
        public int IdUnidade { get; set; }
        public string IdProduto { get; set; }
        public decimal? Qtd { get; set; }
        public decimal? ValorU { get; set; }
        public decimal? Valor { get; set; }
    }
}
