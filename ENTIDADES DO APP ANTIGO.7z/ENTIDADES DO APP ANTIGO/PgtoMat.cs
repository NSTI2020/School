﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class PgtoMat
    {
        public int IdUnidade { get; set; }
        public int IdMatricula { get; set; }
        public int Seq { get; set; }
        public DateTime? Data { get; set; }
        public decimal? Valor { get; set; }
        public decimal? ValorHora { get; set; }
        public decimal? QtdAula { get; set; }
        public decimal? Desconto { get; set; }
        public string MotDesconto { get; set; }
        public int? Convenio { get; set; }
        public string NomeConvenio { get; set; }
    }
}
