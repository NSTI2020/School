﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class NfSaidas
    {
        public int IdNfSaidas { get; set; }
        public string IdOperador { get; set; }
        public string IdCfo { get; set; }
        public string CnpjCliente { get; set; }
        public int? NumeroNf { get; set; }
        public string SerieNf { get; set; }
        public DateTime? DataNf { get; set; }
        public DateTime? DataSaida { get; set; }
        public decimal? TotalNf { get; set; }
        public string Especie { get; set; }
        public int? Situacao { get; set; }
        public DateTime? DataSituacao { get; set; }
        public int? IdTributacao { get; set; }
        public decimal? BaseCalculoIss { get; set; }
        public decimal? AliquotaIss { get; set; }
        public float? TotalInss { get; set; }
        public float? AliquotaCssl { get; set; }
        public float? TotalCssl { get; set; }
        public float? AliquotaPis { get; set; }
        public float? TotalPis { get; set; }
        public float? AliquotaCofins { get; set; }
        public float? TotalCofins { get; set; }
        public float? AliquotaRet { get; set; }
        public float? TotalRet { get; set; }
        public float? TotalIrrf { get; set; }
        public float? AliquotaIrrf { get; set; }
        public decimal? TotalIss { get; set; }
        public int IdUnidade { get; set; }
        public string ChaveDanfe { get; set; }
        public string ProtocoloNfe { get; set; }
        public string ReciboNfe { get; set; }
        public string ReciboCancel { get; set; }
        public int? IdLote { get; set; }
        public string JustCancelamento { get; set; }
        public int? Exportado { get; set; }
        public decimal? ImpostoAprox { get; set; }
    }
}
