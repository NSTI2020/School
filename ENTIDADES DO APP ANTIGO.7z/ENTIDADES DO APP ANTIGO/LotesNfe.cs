﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class LotesNfe
    {
        public LotesNfe()
        {
            HistoricoLotenfe = new HashSet<HistoricoLotenfe>();
        }

        public int IdLote { get; set; }
        public DateTime? DataLote { get; set; }
        public int? QtdNfe { get; set; }
        public string XmlRemessa { get; set; }
        public string ProtocoloLote { get; set; }

        public virtual ICollection<HistoricoLotenfe> HistoricoLotenfe { get; set; }
    }
}
