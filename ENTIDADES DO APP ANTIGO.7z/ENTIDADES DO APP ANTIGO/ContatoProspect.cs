﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ContatoProspect
    {
        public int IdProspect { get; set; }
        public int IdUnidade { get; set; }
        public int IdContato { get; set; }
        public DateTime? Data { get; set; }
        public string Descricao { get; set; }
        public string IdOperador { get; set; }
    }
}
