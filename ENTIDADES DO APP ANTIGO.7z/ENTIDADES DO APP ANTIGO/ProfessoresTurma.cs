﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class ProfessoresTurma
    {
        public int IdTurma { get; set; }
        public int IdUnidade { get; set; }
        public int Sequencia { get; set; }
        public int? IdProfessor { get; set; }
    }
}
