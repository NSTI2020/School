﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Professor
    {
        public Professor()
        {
            AulasDadas = new HashSet<AulasDadas>();
            Disponibilidade = new HashSet<Disponibilidade>();
            Habilitado = new HashSet<Habilitado>();
        }

        public int IdProfessor { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
        public string Telefone2 { get; set; }
        public decimal? HoraAula { get; set; }

        public virtual ICollection<AulasDadas> AulasDadas { get; set; }
        public virtual ICollection<Disponibilidade> Disponibilidade { get; set; }
        public virtual ICollection<Habilitado> Habilitado { get; set; }
    }
}
