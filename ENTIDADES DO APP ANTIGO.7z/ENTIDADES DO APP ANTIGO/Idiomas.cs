﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Idiomas
    {
        public Idiomas()
        {
            Nivel = new HashSet<Nivel>();
        }

        public int IdIdioma { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<Nivel> Nivel { get; set; }
    }
}
