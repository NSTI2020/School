﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class FechamentoProduto
    {
        public int IdFechamento { get; set; }
        public int IdUnidade { get; set; }
        public DateTime? Data { get; set; }
        public string IdOperador { get; set; }
    }
}
