﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class PermissoesPerfil
    {
        public int IdPerfil { get; set; }
        public int Identificador { get; set; }
        public string Descricao { get; set; }
        public string Ativo { get; set; }
        public string Incluir { get; set; }
        public string Excluir { get; set; }
        public string Alterar { get; set; }

        public virtual PerfilOp IdPerfilNavigation { get; set; }
    }
}
