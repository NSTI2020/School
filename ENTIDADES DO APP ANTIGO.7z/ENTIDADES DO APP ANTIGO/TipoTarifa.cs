﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class TipoTarifa
    {
        public TipoTarifa()
        {
            AulasDadas = new HashSet<AulasDadas>();
            Turma = new HashSet<Turma>();
        }

        public int IdTarifa { get; set; }
        public string Descricao { get; set; }
        public decimal? Valor { get; set; }
        public decimal? VlTraslado { get; set; }

        public virtual ICollection<AulasDadas> AulasDadas { get; set; }
        public virtual ICollection<Turma> Turma { get; set; }
    }
}
