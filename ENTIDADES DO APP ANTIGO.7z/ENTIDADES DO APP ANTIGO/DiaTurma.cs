﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class DiaTurma
    {
        public int IdTurma { get; set; }
        public int IdUnidade { get; set; }
        public int Dia { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime? Fim { get; set; }

        public virtual Turma Id { get; set; }
    }
}
