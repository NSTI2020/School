﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class Matricula
    {
        public Matricula()
        {
            RespMat = new HashSet<RespMat>();
        }

        public int IdUnidade { get; set; }
        public int IdMatricula { get; set; }
        public int? IdAluno { get; set; }
        public int? IdTurma { get; set; }
        public DateTime? DataMatricula { get; set; }
        public int? Situacao { get; set; }
        public string Obs { get; set; }
        public int? Tipo { get; set; }
        public int? Nivel { get; set; }
        public int? IdAluno2 { get; set; }

        public virtual ICollection<RespMat> RespMat { get; set; }
    }
}
