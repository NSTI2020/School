﻿using System;
using System.Collections.Generic;

namespace School.WebApi
{
    public partial class AulasDadas
    {
        public int IdAula { get; set; }
        public int IdTurma { get; set; }
        public int? IdProfessor { get; set; }
        public int? IdTarifa { get; set; }
        public DateTime? DataAula { get; set; }
        public DateTime? HoraIni { get; set; }
        public DateTime? HoraFim { get; set; }
        public int? TotalMin { get; set; }
        public string Obs { get; set; }
        public int? Situacao { get; set; }
        public decimal? ValorAula { get; set; }
        public string Descricao { get; set; }
        public int IdUnidade { get; set; }
        public int? Tipo { get; set; }

        public virtual Turma Id { get; set; }
        public virtual Professor IdProfessorNavigation { get; set; }
        public virtual TipoTarifa IdTarifaNavigation { get; set; }
    }
}
